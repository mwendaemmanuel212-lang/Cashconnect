import Link from "next/link";

export default function LoginPage() {
  return <main className="subpage wrap">
    <Link className="brand back-brand" href="/"><span className="brand-mark">P</span>Cash Connect</Link>
    <section className="form-card">
      <span className="eyebrow">CUSTOMER ACCESS</span><h1>Log in to Cash Connect</h1>
      <p className="muted">Secure sign-in will be connected before customer accounts are enabled.</p>
      <label htmlFor="email">Email address</label><input id="email" type="email" placeholder="you@example.com" disabled />
      <label htmlFor="password">Password</label><input id="password" type="password" placeholder="Your password" disabled />
      <button className="button full-width" disabled>Login not enabled yet</button>
      <p className="notice">Preview only: this page does not collect or store credentials.</p>
      <Link className="text-link" href="/">← Back to homepage</Link>
    </section>
  </main>;
}
