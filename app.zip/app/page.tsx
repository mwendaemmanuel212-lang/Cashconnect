import Link from "next/link";

export default function HomePage() {
  return (
    <main>
      <nav className="nav wrap">
        <Link className="brand" href="/"><span className="brand-mark">P</span>Cash Connect</Link>
        <div className="nav-actions"><Link className="nav-link" href="/login">Log in</Link><Link className="button button-small" href="/dashboard">Customer portal</Link></div>
      </nav>
      <section className="hero wrap">
        <div className="hero-copy">
          <div className="eyebrow"><span className="status-dot" /> SIMPLE ACCOUNT MANAGEMENT</div>
          <h1>Your money journey, <span>made clearer.</span></h1>
          <p className="hero-text">Use your Cash Connect customer portal to start a deposit request and keep track of your account activity.</p>
          <div className="hero-actions"><Link className="button" href="/dashboard">Go to customer portal <span aria-hidden="true">→</span></Link><Link className="button button-quiet" href="/login">Customer login</Link></div>
          <p className="micro-note">Preview version · Deposits and withdrawals are not yet connected to a payment provider.</p>
        </div>
        <div className="preview-card">
          <div className="preview-top"><div><span className="small-label">CUSTOMER OVERVIEW</span><h2>Welcome to Cash Connect</h2></div><span className="avatar">PP</span></div>
          <div className="balance-card"><span className="small-label light">ACCOUNT BALANCE</span><div className="balance">KES 0.00</div><span className="balance-caption">Your real balance appears after secure account setup</span></div>
          <div className="activity-head"><strong>Account actions</strong><span className="muted">Preview</span></div>
          <div className="activity-row"><span className="activity-icon">＋</span><div className="activity-text"><strong>Deposit</strong><span>Start a deposit request</span></div><span className="pill pending">Setup needed</span></div>
          <div className="activity-row"><span className="activity-icon neutral">↗</span><div className="activity-text"><strong>Withdraw</strong><span>Not available to customers yet</span></div><span className="pill">Coming soon</span></div>
        </div>
      </section>
      <section className="features-section"><div className="wrap"><div className="section-intro"><span className="eyebrow">CUSTOMER PORTAL</span><h2>Deposits first. Withdrawals controlled.</h2><p>Customers will be able to submit deposit requests. The withdrawal option can remain visible with a “Coming soon” message, while actual withdrawal controls are reserved for an authorized administrator.</p></div>
        <div className="feature-grid">
          <article className="feature"><span className="feature-icon">＋</span><h3>Deposit requests</h3><p>Give customers a clear place to begin a deposit once the payment provider is connected.</p></article>
          <article className="feature"><span className="feature-icon">↗</span><h3>Withdrawal preview</h3><p>The option is visible but unavailable to customers until you decide to enable it.</p></article>
          <article className="feature"><span className="feature-icon">✓</span><h3>Admin control</h3><p>Real withdrawal permissions must be enforced securely on the server, not just hidden in the interface.</p></article>
        </div>
      </div></section>
      <footer className="footer wrap"><Link className="brand" href="/"><span className="brand-mark">P</span>Cash Connect</Link><span>Preview build · Payment integration required</span></footer>
    </main>
  );
}
